# -*- coding: utf-8 -*-
"""한양대 규정 MCP 서버 (실습용)

같은 폴더에 있는 '한양대규정_*.txt' 파일을 읽어 규정을 조문 단위로 정리하고,
안티그라비티 같은 AI가 쓸 수 있는 도구 4개를 제공합니다.

  - find_article     : 주제 → 가장 관련 있는 조문 원문까지 한 번에
  - list_regulations : 규정 목록 (이름으로 거르기)
  - search_regulation: 낱말로 조문 찾기
  - get_article      : 규정 이름과 조 번호로 조문 원문 가져오기

파이썬 기본 기능만 써서 따로 설치할 것이 없습니다.
규정 파일은 읽기만 하고 고치지 않습니다.
"""
import json
import os
import re
import sys
from pathlib import Path

SERVER_NAME = "hanyang-reg"
SERVER_VERSION = "1.1.0"
HERE = Path(__file__).resolve().parent
# 규정 파일은 server.py와 같은 폴더, 없으면 한 단계 위 폴더에서 찾음
REG_DIR = Path(os.environ.get("REG_DIR") or (HERE if any(HERE.glob("한양대규정_*.txt")) else HERE.parent))

TAG = re.compile(r"^\[([^\]]+)\]\s*(?:\[[^\]]*\]\s*)?(.*)$")
ART_NO = re.compile(r"^(제\s*\d+\s*조(?:\s*의\s*\d+)?)\s*(?:\(([^)]*)\))?")


# ---------------------------------------------------------------- 규정 읽기
def load_regulations(folder):
    regs = []
    cur = None
    art = None
    category = ""
    sup = None  # 부칙 묶음

    def close_article():
        nonlocal art
        if art is not None and cur is not None:
            cur["articles"].append(art)
        art = None

    files = sorted(folder.glob("한양대규정_*.txt"))
    for f in files:
        for raw in f.read_text(encoding="utf-8-sig", errors="replace").splitlines():
            line = raw.strip()
            if not line or line.startswith("====") or line.startswith("----"):
                continue
            m = TAG.match(line)
            if not m:
                if art is not None:
                    art["lines"].append(line)
                continue
            tag, text = m.group(1), m.group(2).strip()
            if tag == "CATEGORY_START":
                category = text
            elif tag == "SOURCE":
                close_article()
                cur = {"name": text, "category": category, "file": f.name,
                       "info": "", "articles": [], "supplements": []}
                regs.append(cur)
                sup = None
            elif cur is None:
                continue
            elif tag == "CONTENT":
                cur["info"] = re.sub(r"\s*본문\s*$", "", text.replace(cur["name"], "", 1)).strip()
            elif tag == "ARTICLE":
                close_article()
                sup = None
                am = ART_NO.match(text)
                no = re.sub(r"\s+", "", am.group(1)) if am else text[:12]
                title = (am.group(2) or "") if am else ""
                art = {"no": no, "title": title, "lines": [text]}
            elif tag == "SECTION" and text.startswith("부칙"):
                close_article()
                sup = {"title": text, "lines": []}
                cur["supplements"].append(sup)
            elif tag == "PROVISION" and sup is not None:
                sup["lines"].append(text)
            elif tag in ("PARAGRAPH", "ITEM", "SUBITEM", "ROW", "HEADER"):
                if art is not None:
                    art["lines"].append(text)
                elif sup is not None:
                    sup["lines"].append(text)
            elif tag in ("CHAPTER", "SUBSECTION"):
                close_article()
    close_article()
    for r in regs:
        for a in r["articles"]:
            a["text"] = "\n".join(a.pop("lines"))
    return regs


REGS = load_regulations(REG_DIR)


def norm(s):
    return re.sub(r"[\s·ㆍ・]", "", s or "")


def find_regulations(name):
    """규정 이름으로 찾기: 똑같은 이름 → 포함하는 이름 순서"""
    key = norm(name)
    exact = [r for r in REGS if norm(r["name"]) == key]
    if exact:
        return exact
    return [r for r in REGS if key and key in norm(r["name"])]


# 일상 표현 → 규정에 실제로 쓰이는 말 (문의는 일상어로, 규정은 행정 용어로 쓰여 있음)
SYNONYMS = {
    "출산휴가": ["출산"], "휴가": ["청가", "연가"], "연차": ["연가"], "연차휴가": ["연가"],
    "경조사": ["경조", "청가"], "육아휴직": [("육아", "휴직")], "월급": ["보수"], "급여": ["보수"],
    "야근": ["시간외"], "초과근무": ["시간외"], "출장비": ["여비"],
}


def expand_words(query):
    """낱말마다 [원래 말, 바꿔 볼 말...]. 바꿔 볼 말이 묶음(튜플)이면 그 말들이 모두 들어 있어야 맞음."""
    groups = []
    for w in query.split():
        n = norm(w)
        if n:
            groups.append([(n,)] + [tuple(norm(x) for x in (s if isinstance(s, tuple) else (s,))) for s in SYNONYMS.get(n, [])])
    return groups


def _hit(alt, text):
    return all(x in text for x in alt)


def rank_articles(query, pool):
    """낱말마다 원래 말이나 바꿔 볼 말이 들어 있으면 점수. 조 제목에 들어 있으면 크게 가산."""
    groups = expand_words(query)
    hits = []
    for r in pool:
        for a in r["articles"]:
            body = norm(a["text"]); title = norm(a["title"])
            matched = sum(1 for g in groups if any(_hit(alt, body) for alt in g))
            if not matched:
                continue
            score = matched * 10 \
                + sum(30 for g in groups if any(_hit(alt, title) for alt in g)) \
                + sum(min(body.count(alt[0]), 5) for g in groups for alt in g if _hit(alt, body))
            hits.append((matched, score, r, a))
    full = [h for h in hits if h[0] == len(groups)]
    hits = full or hits
    hits.sort(key=lambda x: (-x[0], -x[1]))
    return hits, bool(full)


def article_key(s):
    s = norm(s)
    m = re.match(r"^제?(\d+)조?(?:의(\d+))?$", s)
    if not m:
        return s
    return "제%s조" % m.group(1) + ("의%s" % m.group(2) if m.group(2) else "")


# ---------------------------------------------------------------- 도구
def tool_list_regulations(args):
    kw = norm(args.get("keyword", ""))
    rows = [r for r in REGS if not kw or kw in norm(r["name"]) or kw in norm(r["category"])]
    if not rows:
        return "'%s'이(가) 들어간 규정이 없습니다. 더 짧은 낱말로 다시 찾아보세요." % args.get("keyword", "")
    out = ["규정 %d개%s" % (len(rows), " (검색어: %s)" % args["keyword"] if kw else "")]
    for r in rows[:200]:
        out.append("- [%s] %s  %s" % (r["category"], r["name"], r["info"]))
    if len(rows) > 200:
        out.append("…(%d개 더 있음. keyword로 범위를 좁히세요)" % (len(rows) - 200))
    return "\n".join(out)


def tool_search_regulation(args):
    query = (args.get("query") or "").strip()
    if not query:
        return "query(찾을 낱말)를 넣어 주세요."
    limit = max(1, min(int(args.get("limit") or 5), 30))
    pool = find_regulations(args["regulation"]) if args.get("regulation") else REGS
    hits, full = rank_articles(query, pool)
    if not hits:
        return "'%s'와 관련된 조문을 찾지 못했습니다. 다른 표현으로 찾아보세요." % query
    out = ["'%s' 검색 결과 %d건 중 %d건%s" % (query, len(hits), min(limit, len(hits)), "" if full else " (일부 낱말만 맞는 결과)")]
    first = query.split()[0]
    for _, _, r, a in hits[:limit]:
        flat = a["text"].replace("\n", " ")
        i = max(0, flat.find(first) - 40) if first in flat else 0
        out.append("- %s %s(%s): %s…" % (r["name"], a["no"], a["title"], flat[i:i + 160]))
    out.append("\n원문은 get_article(regulation, article)로 확인하세요. 한 번에 원문까지 보려면 find_article을 쓰세요.")
    return "\n".join(out)


def tool_find_article(args):
    """주제 → 가장 관련 있는 조문 원문까지 한 번에 (도구 호출 횟수를 줄여 빠르게)"""
    query = (args.get("query") or "").strip()
    if not query:
        return "query(주제)를 넣어 주세요. 예: 배우자 출산휴가"
    n = max(1, min(int(args.get("count") or 1), 3))
    pool = find_regulations(args["regulation"]) if args.get("regulation") else REGS
    hits, full = rank_articles(query, pool)
    if not hits:
        return "'%s'와 관련된 조문을 찾지 못했습니다." % query
    out = []
    for _, _, r, a in hits[:n]:
        out.append("%s (%s)\n%s\n\n%s" % (r["name"], r["category"], r["info"], a["text"]))
    others = ["%s %s(%s)" % (r["name"], a["no"], a["title"]) for _, _, r, a in hits[n:n + 4]]
    if others:
        out.append("다른 후보: " + ", ".join(others))
    return "\n\n---\n\n".join(out)


def tool_get_article(args):
    name = args.get("regulation") or ""
    found = find_regulations(name)
    if not found:
        return "'%s' 규정을 찾지 못했습니다. list_regulations로 정확한 이름을 확인하세요." % name
    if len(found) > 1 and norm(found[0]["name"]) != norm(name):
        return "이름이 비슷한 규정이 여러 개입니다. 하나를 골라 다시 물어 주세요.\n" + \
            "\n".join("- " + r["name"] for r in found[:20])
    r = found[0]
    head = "%s (%s)\n%s" % (r["name"], r["category"], r["info"])
    art = (args.get("article") or "").strip()
    if not art:
        toc = ["%s(%s)" % (a["no"], a["title"]) if a["title"] else a["no"] for a in r["articles"]]
        return head + "\n\n조문 목록(%d개)\n" % len(toc) + "\n".join(toc)
    if norm(art).startswith("부칙"):
        sups = r["supplements"][-3:]
        if not sups:
            return head + "\n\n부칙이 없습니다."
        return head + "\n\n" + "\n\n".join(s["title"] + "\n" + "\n".join(s["lines"]) for s in sups)
    want = article_key(art)
    arts = [a for a in r["articles"] if a["no"] == want]
    if not arts:
        return head + "\n\n%s이(가) 없습니다. article을 비우고 다시 부르면 조문 목록이 나옵니다." % want
    return head + "\n\n" + "\n\n".join(a["text"] for a in arts)


TOOLS = [
    {
        "name": "find_article",
        "description": "주제만 주면 가장 관련 있는 한양대학교 규정 조문의 원문(개정일 포함)을 한 번에 돌려줍니다. 문의에 답할 때 가장 먼저 쓰세요. 일상 표현(출산휴가, 연차, 육아휴직 등)도 규정 용어로 바꿔 찾습니다.",
        "inputSchema": {"type": "object", "properties": {
            "query": {"type": "string", "description": "주제 (예: 배우자 출산휴가, 연차휴가)"},
            "regulation": {"type": "string", "description": "규정 이름 (선택, 예: 직원복무 규정)"},
            "count": {"type": "integer", "description": "가져올 조문 수 (기본 1, 최대 3)"}},
            "required": ["query"]},
        "fn": tool_find_article,
    },
    {
        "name": "list_regulations",
        "description": "한양대학교 규정 목록을 보여 줍니다. keyword를 넣으면 규정 이름이나 분야에 그 낱말이 들어간 것만 보여 줍니다. 각 규정의 제정일·개정일도 함께 나옵니다.",
        "inputSchema": {"type": "object", "properties": {
            "keyword": {"type": "string", "description": "규정 이름에 들어간 낱말 (예: 복무, 보수, 휴가)"}}},
        "fn": tool_list_regulations,
    },
    {
        "name": "search_regulation",
        "description": "한양대학교 규정의 조문 본문에서 낱말을 찾아 관련도 순으로 목록을 보여 줍니다(원문 아님). 일상 표현도 규정 용어로 바꿔 찾습니다. regulation을 넣으면 그 규정 안에서만 찾습니다.",
        "inputSchema": {"type": "object", "properties": {
            "query": {"type": "string", "description": "찾을 낱말 (예: 출산휴가, 연차 휴가)"},
            "regulation": {"type": "string", "description": "규정 이름 (선택, 예: 직원복무 규정)"},
            "limit": {"type": "integer", "description": "최대 결과 수 (기본 5, 최대 30)"}},
            "required": ["query"]},
        "fn": tool_search_regulation,
    },
    {
        "name": "get_article",
        "description": "한양대학교 규정의 조문 원문을 그대로 가져옵니다. article을 비우면 그 규정의 조문 목록을, '부칙'이라고 쓰면 최근 부칙 3개를 보여 줍니다.",
        "inputSchema": {"type": "object", "properties": {
            "regulation": {"type": "string", "description": "규정 이름 (예: 직원복무 규정)"},
            "article": {"type": "string", "description": "조 번호 (예: 제23조, 23, 제4조의2, 부칙). 비우면 조문 목록"}},
            "required": ["regulation"]},
        "fn": tool_get_article,
    },
]


# ---------------------------------------------------------------- MCP(JSON-RPC) 통신
def send(msg):
    sys.stdout.buffer.write((json.dumps(msg, ensure_ascii=False) + "\n").encode("utf-8"))
    sys.stdout.buffer.flush()


def handle(req):
    method = req.get("method")
    rid = req.get("id")
    if rid is None:  # 알림(notifications/...)에는 답하지 않음
        return
    if method == "initialize":
        ver = (req.get("params") or {}).get("protocolVersion") or "2025-06-18"
        return send({"jsonrpc": "2.0", "id": rid, "result": {
            "protocolVersion": ver,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
            "instructions": "한양대학교 규정 %d개를 조문 단위로 찾아 주는 서버입니다. 규정을 인용할 때는 get_article로 원문을 확인하세요." % len(REGS)}})
    if method == "ping":
        return send({"jsonrpc": "2.0", "id": rid, "result": {}})
    if method == "tools/list":
        tools = [{k: v for k, v in t.items() if k != "fn"} for t in TOOLS]
        return send({"jsonrpc": "2.0", "id": rid, "result": {"tools": tools}})
    if method == "tools/call":
        p = req.get("params") or {}
        tool = next((t for t in TOOLS if t["name"] == p.get("name")), None)
        if tool is None:
            return send({"jsonrpc": "2.0", "id": rid, "error": {"code": -32602, "message": "없는 도구: %s" % p.get("name")}})
        try:
            text = tool["fn"](p.get("arguments") or {})
            return send({"jsonrpc": "2.0", "id": rid, "result": {"content": [{"type": "text", "text": text}], "isError": False}})
        except Exception as e:  # 도구 오류는 AI에게 알려 주고 서버는 계속 돎
            return send({"jsonrpc": "2.0", "id": rid, "result": {"content": [{"type": "text", "text": "오류: %s" % e}], "isError": True}})
    send({"jsonrpc": "2.0", "id": rid, "error": {"code": -32601, "message": "지원하지 않는 요청: %s" % method}})


def main():
    if not REGS:
        sys.stderr.write("규정 파일(한양대규정_*.txt)을 찾지 못했습니다: %s\n" % REG_DIR)
    for raw in sys.stdin.buffer:
        line = raw.decode("utf-8", errors="replace").strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            send({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": "JSON 형식 오류"}})
            continue
        for req in (msg if isinstance(msg, list) else [msg]):
            handle(req)


if __name__ == "__main__":
    main()
